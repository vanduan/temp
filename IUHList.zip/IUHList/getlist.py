import cookielib
import urllib2
import httplib2

link_ts = 'http://hui.edu.vn/TuyenSinh/thiSinh/fDHCQXemDiem?noiCallPar=fTimThiSinh&captchaValuePar=_captcha_xxx&soBaoDanhTimPar=SBD_xxx'
link_captcha = 'http://hui.edu.vn/TuyenSinh/Captcha/Show'
cookie_value = 'PHPSESSID=8405jo7rqr460lotoot0pfddk0; '


def get_cookie(url):
    cookies = cookielib.LWPCookieJar()
    handlers = [
        urllib2.HTTPHandler(),
        urllib2.HTTPSHandler(),
        urllib2.HTTPCookieProcessor(cookies)
        ]
    opener = urllib2.build_opener(*handlers)
    req = urllib2.Request(url)
    res = opener.open(req)
    
    for c in cookies:
        return c.name+'='+c.value

cookie_value += get_cookie(link_ts)

#================ Captcha ====================
http = httplib2.Http()
headers = {'Connection':'keep-alive',
           'Referer':link_ts,
            'Cookie':cookie_value}
response, content = http.request(link_captcha, 'GET', headers=headers)

if response['status'] != '200':
    for i in response:
        print i,':',response[i]
    exit(-1)
    
f = open('captcha.png','wb')
f.write(content)
f.close()
#================= Read captcha ===========================
#================= Query TS ===================
#http = httplib2.Http()
#headers = {'Connection':'keep-alive',
#           'Referer':'http://hui.edu.vn/TuyenSinh/thiSinh',
#            'Cookie':cookie_value}
#            
#response, content = http.request(link_ts, 'GET', headers=headers)

#if response['status'] != '200':
#    for i in response:
#        print i,':',response[i]
        
